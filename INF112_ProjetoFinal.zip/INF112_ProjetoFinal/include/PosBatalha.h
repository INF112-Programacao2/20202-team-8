#ifndef POSBATALHA_H
#define POSBATALHA_H

#include "../include/personagem/Equipe.h"

class PosBatalha {
public:
    PosBatalha(Equipe equipe);
    ~PosBatalha();
}; 

#endif //POSBATALHA_H
