#ifndef BATALHA_H
#define BATALHA_H

#include "../include/personagem/Personagem.h"
#include "../include/personagem/Arqueiro.h"
#include "../include/personagem/Barbaro.h"
#include "../include/personagem/Bardo.h"
#include "../include/personagem/Guerreiro.h"
#include "../include/personagem/Ladino.h"
#include "../include/personagem/Mago.h"
#include "../include/personagem/Paladino.h"
#include "../include/personagem/Sacerdote.h"
#include "../include/personagem/Equipe.h"
#include "../include/PosBatalha.h"
#include "../include/inimigo/Inimigo.h"
#include "../include/inimigo/Slime.h"
#include "../include/inimigo/Skull.h"
#include "../include/inimigo/Troll.h"
#include "../include/inimigo/Witcher.h"
#include "../include/inimigo/EquipeInimiga.h"

class Batalha
{
    public:

    //Criacao das equipes da torre de 10 andares
    EquipeInimiga equipe_torre1(),equipe_torre2(),equipe_torre3(),equipe_torre4(),equipe_torre5();
    EquipeInimiga equipe_torre6(),equipe_torre7(),equipe_torre8(),equipe_torre9(),equipe_torre10();
    
    //Ordem da batalha
    int velocidade_a = 0, velocidade_b = 0;
    int ordem;

    //Construtor e Destrutor
    Batalha();
    ~Batalha();

    void Torre(Equipe &jogador);
    int OrdenaBatalha(Equipe &jogador, EquipeInimiga &inimigos);
    double acao(int numero, Equipe &jogador, EquipeInimiga &inimigos);
};

#endif // BATALHA_H