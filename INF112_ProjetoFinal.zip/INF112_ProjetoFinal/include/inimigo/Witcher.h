#ifndef WITCHER_H
#define WITCHER_H

#include "Inimigo.h"

class Witcher : public Inimigo {
public:
    Witcher(int nivel);
    ~Witcher();

    bool _Transformada = false;

    // ATAQUE E DEFESA
    virtual int atacar() override;
    virtual int defender() override;

    // HABILIDADE ESPECIAL
    virtual double ataque_1() override;
    virtual double ataque_2() override;
    virtual double ataque_3() override;
    virtual double ataque_4() override;
};

#endif // WITCHER_H