#ifndef LADINO_H
#define LADINO_H

#include <string>
#include "Personagem.h"

class Ladino : public Personagem {
public:
    Ladino(std::string nome, int forca, int destreza, int constituicao, int inteligencia);
    ~Ladino();

    // ATAQUE E DEFESA
    virtual int atacar() override;
    virtual int defender() override;

    // HABILIDADE ESPECIAL
    virtual double ataque_1() override;
    virtual double ataque_2() override;
    virtual double ataque_3() override;
    virtual double ataque_4() override;
};

#endif // LADINO_H