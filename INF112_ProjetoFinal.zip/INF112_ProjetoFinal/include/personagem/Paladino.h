#ifndef PALADINO_H
#define PALADINO_H

#include <string>
#include "Personagem.h"

class Paladino : public Personagem {
public:
    Paladino(std::string nome, int forca, int destreza, int constituicao, int inteligencia);
    ~Paladino();

    // ATAQUE E DEFESA
    virtual int atacar() override;
    virtual int defender() override;

    // HABILIDADE ESPECIAL
    virtual double ataque_1() override;
    virtual double ataque_2() override;
    virtual double ataque_3() override;
    virtual double ataque_4() override;

};

#endif // PALADINO_H