#include <iostream>
#include <vector>
#include "../include/Batalha.h"

Batalha::Batalha()
{

}

Batalha::~Batalha()
{

}

void Batalha::Torre(Equipe &jogador)
{
    //1 andar da torre
    Slime slime1_1(1),slime1_2(1),slime1_3(1),slime1_4(1); 
    EquipeInimiga equipe_torre1(slime1_1,slime1_2,slime1_3,slime1_4);

    do
    {
        ordem = OrdenaBatalha(jogador, equipe_torre1);
        if(ordem == 1)
        {
            acao(0, jogador, equipe_torre1);            

    
            /*acao(1, jogador);
            acao(2, jogador);
            acao(3, jogador);*/







        }

        else{}

    }while(jogador.get_tamanho_equipe() != 0 || equipe_torre1.get_tamanho_equipe_inimiga() != 0);

    //2 andar da torre
    Slime slime2_1(2),slime2_2(2),slime2_3(2),slime2_4(2); 
    EquipeInimiga equipe_torre2(slime2_1,slime2_2,slime2_3,slime2_4);

    //3 andar da torre
    Slime slime3_1(3),slime3_2(3);
    Skull skull3_1(3),skull3_2(3); 
    EquipeInimiga equipe_torre3(slime3_1,slime3_2,skull3_1,skull3_2);

    //4 andar da torre
    Skull skull4_1(4),skull4_2(4),skull4_3(4),skull4_4(4); 
    EquipeInimiga equipe_torre4(skull4_1,skull4_2,skull4_3,skull4_4);
    
    //5 andar da torre
    Skull skull5_1(5),skull5_2(5);
    Troll troll5_1(5),troll1_2(5); 
    EquipeInimiga equipe_torre5(skull5_1,skull5_2,troll5_1,troll1_2);
    
    //6 andar da torre
    Troll troll6_1(6),troll6_2(6),troll6_3(6),troll6_4(6); 
    EquipeInimiga equipe_torre6(troll6_1,troll6_2,troll6_3,troll6_4);
    
    //7 andar da torre
    Slime slime7_1(7);
    Skull skull7_1(7);
    Troll troll7_1(7),troll7_2(7);
    EquipeInimiga equipe_torre7(slime7_1,skull7_1,troll7_1,troll7_2);

    //8 andar da torre
    Skull skull8_1(8), skull8_2(8);
    Troll troll8_1(8),troll8_2(8);
    EquipeInimiga equipe_torre8(skull8_1,skull8_2,troll8_1,troll8_2);
    
    //9 andar da torre
    Slime slime9_1(9);
    Skull skull9_1(9);
    Troll troll9_1(9);
    Witcher witcher9_1(9);
    EquipeInimiga equipe_torre9(slime9_1,skull9_1,troll9_1,witcher9_1);
    
    //10 andar da torre
    Skull skull10_1(10);
    Troll troll10_1(10),troll10_2(10);
    Witcher witcher10_1(10);
    EquipeInimiga equipe_torre10(skull10_1,troll10_1,troll10_1,witcher10_1);
}

int Batalha::OrdenaBatalha(Equipe &jogador, EquipeInimiga &inimigos)
{
    for(int i = 0; i < jogador.get_tamanho_equipe(); i ++)
    {
        velocidade_a += jogador.get_personagem(i)->get_velocidade_batalha();
    }

    for(int i = 0; i < inimigos.get_tamanho_equipe_inimiga(); i ++)
    {
        velocidade_b += inimigos.get_inimigo(i)->get_velocidade();    
    }
    
    if(velocidade_a > velocidade_b)
        return 1;
    else    
        return 2;
}

double Batalha::acao(int numero, Equipe &jogador, EquipeInimiga &inimigos)
{
    double op;
    std::cout<<"-----------------------------------------------------------------------"<<std::endl;
    std::cout<<"Turno de *"<<jogador.get_personagem(numero)->get_nome()<<"* , realize uma acao!"<< std::endl;
    std::cout<<"1) Atacar: "<<std::endl;
    std::cout<<"2) Defender: "<<std::endl;
    std::cout<<"3) Usar Habilidade1: "<<std::endl;
    std::cout<<"4) Usar Habilidade2: "<<std::endl;
    std::cout<<"-----------------------------------------------------------------------"<<std::endl;
    std::cin>>op;

    double posicao_inimigo = inimigos.get_tamanho_equipe_inimiga();
    std::cout<<"-----------------------------------------------------------------------"<<std::endl;
    std::cout<<"Quem voce deseja atacar?"<< std::endl;
    if(posicao_inimigo > 0)
    std::cout<<"1)"<<inimigos.get_inimigo(0)->get_nome()<<std::endl;
    if(posicao_inimigo > 1)
    std::cout<<"2)"<<inimigos.get_inimigo(1)->get_nome()<<std::endl;
    if(posicao_inimigo > 2)
    std::cout<<"3)"<<inimigos.get_inimigo(2)->get_nome()<<std::endl;
    if(posicao_inimigo >= 3)
    std::cout<<"4)"<<inimigos.get_inimigo(3)->get_nome()<<std::endl;
    std::cout<<"-----------------------------------------------------------------------"<<std::endl;
    std::cin>>posicao_inimigo;

    if(op == 1)
    {
        inimigos.get_inimigo(posicao_inimigo)->set_vida(inimigos.get_inimigo(posicao_inimigo)->get_vida() - jogador.get_personagem(numero)->atacar());

    }

    return 0;

}

/* void Batalha::TorreBatalha()
{

}


/*
void InformacoesTestePersonagens(Equipe &jogador){

    jogador.IfPersonagem_morrer();
    std::cout<<"------------INFORMACOES------------"<<std::endl;
    for(int i=0; i<jogador.get_tamanho_equipe(); i++){

        std::cout<<std::endl;
        std::cout<<"Nome: "<<jogador.get_personagem(i)->get_nome()<<std::endl;
        std::cout<<"Ataque: "<<jogador.get_personagem(i)->get_ataque()<<std::endl;
        std::cout<<"Defesa: "<<jogador.get_personagem(i)->get_defesa()<<std::endl;
        std::cout<<"Vida: "<<jogador.get_personagem(i)->get_vida()<<std::endl;
        std::cout<<"Mana: "<<jogador.get_personagem(i)->get_mana()<<std::endl;
        std::cout<<"Dano Magico: "<<jogador.get_personagem(i)->get_dano_magico()<<std::endl;
        std::cout<<"Acerto: "<<jogador.get_personagem(i)->get_acerto()<<std::endl;
        std::cout<<"Velocidade: "<<jogador.get_personagem(i)->get_velocidade()<<std::endl;
        std::cout<<std::endl;
    }

}

void InformacoesTesteInimigos(EquipeInimiga &jogador){

    jogador.IfInimigo_morrer();
    std::cout<<"------------INFORMACOES------------"<<std::endl;
    for(int i=0; i<jogador.get_tamanho_equipe_inimiga(); i++){

        std::cout<<std::endl;
        std::cout<<"Nome: "<<jogador.get_inimigo(i)->get_nome()<<std::endl;
        std::cout<<"Ataque: "<<jogador.get_inimigo(i)->get_ataque()<<std::endl;
        std::cout<<"Defesa: "<<jogador.get_inimigo(i)->get_defesa()<<std::endl;
        std::cout<<"Vida: "<<jogador.get_inimigo(i)->get_vida()<<std::endl;
        std::cout<<"Mana: "<<jogador.get_inimigo(i)->get_mana()<<std::endl;
        std::cout<<"Dano Magico: "<<jogador.get_inimigo(i)->get_dano_magico()<<std::endl;
        std::cout<<"Acerto: "<<jogador.get_inimigo(i)->get_acerto()<<std::endl;
        std::cout<<"Velocidade: "<<jogador.get_inimigo(i)->get_velocidade()<<std::endl;
        std::cout<<std::endl;
    }

}

int main(int argc, char** argv){

    Paladino paladin("Paladino",0,0,0,0);
    Barbaro barbarian("Barbaro",0,0,0,0);
    Guerreiro warrior("Guerreiro",0,0,0,0);
    Sacerdote cleric("Sacerdote",0,0,0,0);
    Bardo bard("Bardo",0,0,0,0);
    Mago mage("Mago",0,0,0,0);
    Arqueiro ranger("Arqueiro",0,0,0,0);
    Ladino rougue("Ladino",0,0,0,0);
    Equipe equipe_jogador(paladin,cleric,mage,ranger);
    
    InformacoesTestePersonagens(equipe_jogador);

    //testando pos batalha
    PosBatalha batalha1(equipe_jogador);

    //2 PERSONAGENS MORRERAM NA BATALHA

    equipe_jogador.get_personagem(0)->set_vida_batalha(0.0);
    equipe_jogador.get_personagem(1)->set_vida_batalha(0.0);

    //teste 2
    InformacoesTestePersonagens(equipe_jogador);
    
    // TESTE COM OS INIMIGOS
    Slime slime(3);
    Skull skull(1);
    Witcher witcher(2);
    Troll troll(3);

    EquipeInimiga equipe_inimiga(slime,skull,witcher,troll);

    InformacoesTesteInimigos(equipe_inimiga);

    //MATEI 2 PERSONAGENS (SKULL E TROLL)
    equipe_inimiga.get_inimigo(1)->set_vida(0);
    equipe_inimiga.get_inimigo(3)->set_vida(0);

    //TESTE
    InformacoesTesteInimigos(equipe_inimiga);
    
    return 0;
}
*/